### It is only made for a few select colleges  ###
print("Welcome to Delhi University akinator")
print(" ")
NC = input("It is a north campus college, yes or no \n")
if NC == "yes":
  NCW = input("It is a women only college, yes or no \n")
  if NCW == "yes":
    print("The college is Miranda House")
  if NCW == "no":  
    NCM = input("Does the name of the college start with S, yes or no \n")
    if NCM == "yes":
      NAA = input("The college only offers two  courses, yes or no \n")
      if NAA == "yes":
        print("The college is Shri Ram College of  Commerce")
      else:
        SMC = input("It is a Sikh Minority college?, yes or no \n")
        if SMC == "yes":
          SMCF = input("The college has 'Commerce'in its name, yes or no \n")
          if SMC == "yes":
            if SMCF == "no":
              print("The college is SGTB Khalsa")
            else:
              print("The college is Sri Guru Gobind College of Commerce")
        else:
          print("The college is St. Stephens")
    if NCM == "no":
      HC = input("Does the name of the college start with H, yes or no \n")
      if NCM == "no":
        if HC == "yes":
          HCHIN = input("The college has the name of religion in its name, yes or no \n")
          if  HCHIN == "yes":
            print("The college is Hindu College")
          else:
            print("The college is Hansraj College")  
    if NCM == "no":
      if HC == "no":
        Ramjas = input("The name of the college starts with R, yes or no \n")
        if  Ramjas == "yes":
          print("The college is Ramjas College")
    if NCM == "no":
      if HC == "no":
        if Ramjas == "no":
          DC = input("The name of the college starts with D, yes or no \n")
          if DC == "yes":
            Eco = input("The college has 'Economics' in its name, yes or no \n")
            if Eco == "yes":
              print("The college is Delhi School of Economics")
            else:
              print("The college is Dalaut Ram College")
if NC == "no":
  SC = input("It is a south campus college, yes or no \n")
  if SC == "yes":
    SCW = input("It is a women only college, yes or no \n")
    if SCW == "yes":
      LSR = input("The name of the college starts  with L, yes or no \n")
      if LSR == "yes":
        print("The name of the college is Lady Shri Ram College")
      else:
        print("The name of the college is Kamala Nehru College")
    if SCW != "yes":
      SCA = input("The name of the college starts with A, yes or no \n")
      if SCA == "yes":
        Arya = input("The college is named after an Indian mathematician, yes or no \n")
        if Arya ==  "yes":
         print("The college is Aryabhatta college")
        else:
          print("The college is Atma Ram Sanatan Dharma College") 
      if SCA == "no":
        print("The college is Sri Venkateshwara College")
if NC == "no":
  if SC == "no":
    OC = input("It is a off campus college, yes or no \n")
    if OC == "yes":
      S = input("The name of the college start with S, yes or no \n")
      if S == "yes":
        Shi = input("The college is named after a medieval warrior, yes or no \n")
        if Shi == "yes":
          print("The college is Shivaji College")
        if Shi != "yes":
          Sha = input("The college is named after a freedom fighter, yes or no \n")
        if Sha == "yes":
          print("The name of the college is Shaheed Bhagat Singh College of Business")
        if Sha == "no":
          SA = input("The college is named after an Indian philosopher, yes or no \n")
        if SA == "yes":
          print("The college is Sri Aurobindo College")
        else:
          print("The College is Satayawati College")
    if OC == "yes":
      R = input ("The name of the college starts with R, yes or no \n")
      if R == "yes":
        Rama = input("The college is named after an Indian Mathematician, yes or no \n")
        if Rama == "yes":
          print("The name of the college is Ramanujan College")
        else:
          print("The college is Rajdhani College")
         
    
    
                 